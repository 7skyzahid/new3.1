<?php $__env->startSection('style'); ?>
@parent
<link rel="stylesheet" href="<?php echo asset('css/faq.css')?>" type="text/css"> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br><br>
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1">

			<?php if(Auth::user()->name == $id): ?>
			<center><h1>Jobs Posted By: Me</h1></center><br>
			<?php else: ?>
			<center><h1>Jobs Posted By: <?php echo e($id); ?></h1></center><br>
			<?php endif; ?>
			
			<?php if((Auth::check() == true) && (Auth::user()->name == $id)): ?>
			<a href="/dashboard/create"><button class="btn btn-primary">Post A New Job</button></a><br><br>
			<?php endif; ?>
			
			<?php foreach($posts as $post): ?>
			<div class="panel panel-default"> 
				<div class="panel-heading">Title: <a href="/dashboard/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a> 
					; at amount $<?php echo e($post->amount); ?> 
					<?php if($post->payment_type == "full time"): ?>
						(full time basis)
					<?php elseif($post->payment_type == "hourly"): ?>
						/ hour basis
					<?php endif; ?>	

				</div>
				<div class="panel-body">
					Keywords: 	&nbsp 	<?php echo e($post->tags); ?><br>
					Start Date: &nbsp 	<?php echo e($post->startdate); ?><br>
					Deadline: 	&nbsp 	<?php echo e($post->deadline); ?><br>
					Description:&nbsp	<?php echo e($post->description); ?>

				</div>

				<?php if((Auth::check()== true) && (Auth::user()->name == $post->author)): ?>
				<div>
				<form method="POST" action="/dashboard/<?php echo e($post->id); ?>" id="fb">
					<?php echo e(method_field('DELETE')); ?>

    				<?php echo e(csrf_field()); ?>

					<button type="button" class="btn btn-primary" onclick="window.location.href='/dashboard/<?php echo e($post->id); ?>/editpost'">Edit</button>					
					<button type="submit" class="btn btn-primary" >Delete</button>
				</form>
				</div>
				<?php elseif((Auth::check()== true) && (Auth::user()->name != $post->author)): ?>
					<div id="notifier<?php echo e($post->id); ?>" style="background-color:green;color:white;display:none;">Your bid has successfully been placed!</div>
					<div class="toggle">
						<div class="toggle-title">
							<button type="button" class="btn btn-primary title-name togglecloser" id="pressbid<?php echo e($post->id); ?>" onclick="opentoggle(<?php echo e($post->id); ?>)">Bid</button>
						</div>


						<div class="toggle-inner">
							
							<div class="form-group row">
								<label for="biddesc" class="col-xs-offset-1 col-xs-3 col-form-label">Why should we hire you?</label>
								<div class="col-xs-7">
									<textarea required class="form-control" name="biddesc<?php echo e($post->id); ?>" placeholder="Why should we hire you?" rows="3" type="text" id="biddesc<?php echo e($post->id); ?>"></textarea>
								</div>
							</div>

							<div class="form-group row">
								<label for="amount" class="col-xs-offset-1 col-xs-3 col-form-label">Amount</label>
								<div class="col-xs-7">
									<input required class="form-control" name="amount<?php echo e($post->id); ?>" type="number" min="1" id="amount<?php echo e($post->id); ?>">
								</div>
							</div>

							<div class="form-group row col-xs-offset-4">
								<button type="button" class="btn btn-primary title-name" id="submitbid<?php echo e($post->id); ?>" onclick="placebid(<?php echo e($post->id); ?>)">Submit Bid</button>
								<button type="button" class="btn btn-primary title-name" id="cancelbid<?php echo e($post->id); ?>" onclick="closetoggle(<?php echo e($post->id); ?>)">Cancel Bid</button>
							</div>
						</div>
					</div>
					<div id="testdiv"></div>

				<?php endif; ?>
				
			</div>
			<?php endforeach; ?>
		
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

	function opentoggle(id){
		$(".togglecloser").removeClass("active").closest('.toggle').find('.toggle-inner').slideUp(200);
		$("#pressbid"+id).addClass("active").closest('.toggle').find('.toggle-inner').slideDown(200);	
	}

	function closetoggle(id){
		$("#biddesc"+id).val("");
		$("#amount"+id).val("");
		jQuery(".togglecloser").removeClass("active").closest('.toggle').find('.toggle-inner').slideUp(200);
	}

	function placebid(id){
		$.ajax({
			type: "POST",
			url: "/jobpost",
			data: {postid: id, description: $("#biddesc"+id).val(), amount: $("#amount"+id).val(),  _token: "<?php echo e(Session::token()); ?>"},
			success: function(result){
	    					$("#biddesc"+id).val("");
							$("#amount"+id).val("");
							$(".togglecloser").removeClass("active").closest('.toggle').find('.toggle-inner').slideUp(200);
							$("#notifier"+id).show().delay( 5000 ).hide(0);
	        }
		});
		
	}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>