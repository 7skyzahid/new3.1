<?php $__env->startSection('content'); ?>
<br><br>
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1">
			<center><h1> All Blogs</h1></center>
			<br><br>
			<?php if(Auth::check()== true): ?>
			<a href="/blogs/create"><button class="btn btn-primary">Write A New Blog</button></a><br><br>
			<?php endif; ?>
			
			<?php foreach($blogs as $blog): ?>
			<div class="panel panel-default"> 
				<div class="panel-heading">"<a href="/blogs/<?php echo e($blog->id); ?>"><?php echo e($blog->title); ?></a>" by <a href="/<?php echo e($blog->author); ?>"><?php echo e($blog->author); ?></a></div>
				<div class="panel-body">
					<?php echo e($blog->body); ?>

				</div>

				<?php if((Auth::check()== true) && (Auth::user()->name == $blog->author)): ?>
				<div>
				<form method="POST" action="/blogs/<?php echo e($blog->id); ?>" id="fb">
					<?php echo e(method_field('DELETE')); ?>

    				<?php echo e(csrf_field()); ?>

					<button type="button" class="btn btn-primary" onclick="window.location.href='/blogs/<?php echo e($blog->id); ?>/editblog'">Edit</button>					
					<button type="submit" class="btn btn-primary" >Delete</button>
				</form>
				</div>
				<?php endif; ?>

			</div>
			<?php endforeach; ?>
		
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>