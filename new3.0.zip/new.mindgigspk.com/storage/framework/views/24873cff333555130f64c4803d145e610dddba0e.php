<?php $__env->startSection('content'); ?>
<style>
  .img-profile
   {
       position: relative;
       float: left;
       width:  100px;
       height: 100px;
       background-position: 50% 50%;
       background-repeat:   no-repeat;
       background-size:     cover;
   }
</style>
<ul>

    <?php foreach($data as $cells): ?>
    <li class="row" style="background-color: floralwhite">

        <!-- Date -->
        <div class="col-md-3">
            <div class="photo">
                <h4>Photo</h4>
                 <?php if(isset($cells->profilepic)): ?>

                    <img src="<?php echo e(asset('images').'/'.$cells->profilepic); ?>" alt="" class="img-circle img-responsive img-profile" >

                <?php else: ?>
                    <img src="images/download.png" alt="" class="img-circle img-responsive img-profile" >
                    <?php endif; ?>
            </div>
        </div>
        <!-- End Date -->
        <div class="col-md-9">
            <div class="name">
                <h4><?php echo e($cells->bidedname); ?>

                </h4>
            </div>
            <p><?php echo e($cells->proposals); ?><span class="pull-right badge" style="font-size: large">$<?php echo e($cells->budget); ?></span> </p>
           <div>
               <a href="<?php echo e(URL::to($cells->bidedname)); ?>"> <button>Visit profile</button></a>

        <form method="post" action="/sendmessenger">
            <input type="hidden" value="<?php echo e(Auth::user()->name); ?>" name="senderid">
            <input type="hidden" value="<?php echo e($cells->id); ?>" name="projectid">
            <input type="hidden" value="<?php echo e($cells->bidid); ?>" name="bidid">
            <input type="hidden" value="<?php echo e($cells->bidedname); ?>" name="recieverid">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <button type="submit">Contact <?php echo e($cells->bidedname); ?></button>
        </form>

           </div>

        </div>
    </li>

    <?php endforeach; ?>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>