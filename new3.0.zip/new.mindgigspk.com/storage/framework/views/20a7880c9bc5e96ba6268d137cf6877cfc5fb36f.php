<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/navbar.css')?>" type="text/css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('navbar'); ?>

    <header class="">
        <div class="container">
            <div class="sixteen columns">

                <!-- Logo -->
                <div id="logo">
                    <h1>
                        <!-- Branding Image -->
                        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                            <img class="img img-responsive " src="<?php echo e(URL::to('/')); ?>/images/mindGigs-logo-high-res.jpg" width="250" height="250">
                        </a>
                    </h1>
                </div>

                <!-- Menu -->
                <nav id="navigation" class="menu">
                    <ul id="responsive">
                        <li><a href="/">Home</a>
                            <ul class="sf-menu">
                                <li> <a class="btn btn-default" href="<?php echo e(url('/faq')); ?>">FAQ</a></li>
                                <li>  <a class="btn btn-default" href="<?php echo e(url('/home')); ?>">Home</a></li>
                               
                              
                              
                                <li><a class="btn btn-default" href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                            
                                <li><a class="btn btn-default" href="<?php echo e(url('/aboutUs')); ?>">About Us</a></li>
                            </ul>
                        </li>

                        <li><a href="#">For Candidates</a>
                            <ul class="sf-menu">
                                <li><a class="btn btn-default" href="<?php echo e(url('/profile')); ?>">Profile</a></li>
                                <li> <a class="btn btn-default" href="<?php echo e(url('/scoreboard')); ?>">Scoreboard</a></li>
                                <li><a class="btn btn-default" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
                                <li><a class="btn btn-default" href="<?php echo e(url('/dashboard')); ?>">Jobs View</a></li>
                                <li><a class="btn btn-default" href="<?php echo e(url('/freelancers')); ?>">All Candidates</a></li>
                            </ul>
                        </li>

                        <li><a href="#">For Employers</a>
                            <ul class="sf-menu">
                                <li><a class="btn btn-default" href="<?php echo e(url('/managerequest')); ?>">Manage Requests</a></li>
                                 <li><a class="btn btn-default" href="<?php echo e(url('/blogs')); ?>">Blogs</a></li>
                                <li><a class="btn btn-default" href="<?php echo e(url('/searchjobs')); ?>">Jobs Search</a></li>
                                <li><a class="btn btn-default" href="<?php echo e(url('/managepost')); ?>">Manage Posts</a></li>
                                <li><a class="btn btn-default" href="<?php echo e(url('/dashboard/create')); ?>">Jobs Post</a></li>
                            </ul>
                        </li>
                        <li>
                            <form class="navbar-form"  method="post" action="/skillsearch">
                                <div class="input-group">
                                    <?php echo csrf_field(); ?>


                                    <input type="text" name="tosearch" class="form-control"  id="skilltitle" style="width: 280px" placeholder="Search for Skills">
                                    <div class="input-group-btn"> <input type="submit"  class="btn btn-default" value="Search" style="padding-bottom: 5px;"> </div>
                                </div>
                            </form>
                        </li>
                    </ul>

                        <!-- Right Side Of Navbar -->
                        <ul class="responsive float-right" class="sf-menu">
                            <!-- Authentication Links -->
                            <?php if(Auth::guest()): ?>
                                <li><a href="<?php echo e(url('/login')); ?>"> Login</a></li>
                                <li><a href="<?php echo e(url('/register')); ?>"> Register</a></li>
                            <?php else: ?>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                        <?php echo e(Auth::user()->name); ?>

                                    </a>
                                    <ul class="dropdown-menu" role="menu" class="sf-menu">
                                        <li><a href="<?php echo e(url('/'.Auth::user()->name.'/')); ?>"><i class="fa fa-btn fa-user"></i>View My Profile</a></li>
                                        <li><a href="<?php echo e(url('/'.Auth::user()->name.'/blogs')); ?>"><i class="fa fa-btn fa-user"></i>View My Blogs</a></li>
                                        <li><a href="<?php echo e(url('/'.Auth::user()->name.'/dashboard')); ?>"><i class="fa fa-btn fa-user"></i>View My Dashboard</a></li>
                                        <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                        </ul>

                </nav>

                <!-- Navigation -->
                <div id="mobile-navigation">
                    <a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a>
                </div>

            </div>
        </div>
    </header>

<?php $__env->stopSection(); ?>

<!-- JavaScripts -->

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(function () {
            "use strict";

            $(window).scroll(function () {
                var $scrollTop = $(this).scrollTop();

                if ($scrollTop > 100) {
                    $(".navbar").addClass("navbar-active");
                } else {
                    $(".navbar").removeClass("navbar-active");
                }
            });


        });
    </script>
     <script>
        $(function()
        {
            $( "#skilltitle" ).autocomplete({
                source: "<?php echo e(URL::route('skillcomplete')); ?>",
                minLength: 1,
                select: function(event, ui) {

                }
            });
        });


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>