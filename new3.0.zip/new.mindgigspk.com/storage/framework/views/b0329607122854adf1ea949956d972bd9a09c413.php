<!-- Main Content -->
<?php $__env->startSection('content'); ?>
<div class="container login-form">
    <h2 class="login-title"> Reset Password </h2>
    <div class="panel panel-default">
        <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/password/email')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <div class="login-userinput input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
                                <input id="email" type="email" placeholder="Email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                            </div>
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <div class="checkbox login-options">

                        <a class="login-forgot" href="#" onclick="$(this).closest('form').submit();"><i class="fa fa-envelope"></i> Send Password Reset Link </a>

                        </div>
                    </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>