<?php $__env->startSection('navbar'); ?>

    <!-- Theme-options -->
    <!-- End Theme-options -->
<!-- Login Client -->
        <div class="jBar">
          <div class="container">            
              <div class="row">    

                  <div class="col-md-10">
                     <div class="row padding-top-mini">
                        <!-- Item service-->
                        <div class="col-md-4">
                            <div class="item-service border-right">
                                <div class="row head-service">
                                    <div class="col-md-2">
                                        <i class="fa fa-check-square"></i>                             
                                    </div>
                                    <div class="col-md-10">
                                        <h5>Login or create new account.</h5>
                                    </div>
                                </div>  
                                <p>Pellentesque habitant morbi fames ac turpis egestas. Vestibulum tortor quam. Pellentesque habitant</p>
                            </div>
                        </div>      
                        <!-- End Item service-->

                        <!-- Item service-->
                        <div class="col-md-4">
                            <div class="item-service border-right">
                                <div class="row head-service">
                                    <div class="col-md-2">
                                        <i class="fa fa-star"></i>                             
                                    </div>
                                    <div class="col-md-10">
                                        <h5>Review your order.</h5>
                                    </div>
                                </div>  
                                <p>Pellentesque habitant morbi fames ac turpis egestas. Vestibulum tortor quam Pellentesque habitant.</p>
                            </div>
                        </div>      
                        <!-- End Item service-->

                        <!-- Item service-->
                        <div class="col-md-4">
                            <div class="item-service border-right">
                                <div class="row head-service">
                                    <div class="col-md-2">
                                        <i class="fa fa-credit-card"></i>                             
                                    </div>
                                    <div class="col-md-10">
                                        <h5>Payment And FREE shipment.</h5>
                                    </div>
                                </div>  
                                <p>Pellentesque habitant morbi fames ac turpis egestas. Vestibulum tortor quam. Pellentesque habitant</p>
                            </div>
                        </div>      
                        <!-- End Item service-->
                     </div>
                  </div>

                  <div class="col-md-2">
                      <h5>Client Login</h5>
                      <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                          <?php echo e(csrf_field()); ?>

                            <input type="text" placeholder="Username" required>
                            <input type="password" placeholder="Password" required>
                            <input type="submit" class="btn btn-primary" value="sign in">
                            <span>Or</span>                       
                            <a href="/register" class="btn btn-primary">Register</a>
                      </form>
                  </div>

                            
                  <span class="jTrigger downarrow"><i class="fa fa-minus"></i></span>
              </div>
          </div>
      </div>
      <span class="jRibbon jTrigger up" title="Login"><i class="fa fa-plus"></i></span>
      <div class="line"></div>
      <!-- End Login Client -->

        <!-- Info Head -->
    <section class="info-head">
            <div class="container">
                <ul>
                    <li><i class="fa fa-headphones"></i> 01800034567</li>
                    <li><i class="fa fa-comment"></i> <a href="#">Live chat</a></li>


					<?php if(! Auth::guest()): ?>
                    <?php echo $__env->make('layouts.notifications', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php endif; ?>
                    <li><i class="fa  fa-dashboard"></i>Dashboard </li>
                   <li><a href="conversation"> <i class="fa  fa-inbox"></i>Inbox</a> </li>
                    <li><i class="fa  fa-shopping-cart"></i>Shopping Cart </li>

                    <li>
                        <ul>
                            <li class="dropdown">
                                <i class="fa fa-btn fa-user"></i>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <?php if(Auth::guest()): ?>
                                        Member
                                    <?php else: ?>
                                        <?php echo e(Auth::user()->name); ?>

                                    <?php endif; ?>
                                    <i class="fa fa-angle-down"></i>
                                </a>
                                <ul class="dropdown-menu">
                                    <?php if(Auth::guest()): ?>
                                        <li> <a href="<?php echo e(url('/login')); ?>" > <i class="fa fa-btn fa-user"></i>Login</a></li>
                                        <li><a href="<?php echo e(url('/register')); ?>" > <i class="fa fa-btn fa-user"></i>Register</a></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e(url('/'.Auth::user()->name.'/')); ?>"><i class="fa fa-btn fa-user"></i>Profile</a></li>
                                        <li><a href="<?php echo e(url('/'.Auth::user()->name.'/blogs')); ?>"><i class="fa fa-btn fa-user"></i>Blogs</a></li>
                                        <li><a href="<?php echo e(url('/'.Auth::user()->name.'/dashboard')); ?>"><i class="fa fa-btn fa-user"></i>Dashboard</a></li>
                                        <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        </ul>
                    </li>

                </ul>
            </div>
    </section>
        <!-- Info Head -->


<!-- Header-->
    <header class="animated fadeInDown delay1">           
        <div class="container">
             <div class="row col-md-12"> 
 <!-- Logo-->
            <div class="col col-md-2 logo">
                <a href="<?php echo e(url('/')); ?>">                            
                    <img src="<?php echo e(asset('images/mindGigs-logo-high-res.jpg')); ?>" alt="Logo">
                </a>
            </div>
                    <!-- End Logo-->
                                                      
                    <!-- Nav-->
                 <div  class="col-md-10">
                 <nav>
                     <!-- Menu-->
                     <ul id="menu" class="sf-menu">
                         <li>
                             <a href="/">HOME <i class="fa fa-angle-down"></i></a>
                             <ul>
                                 <li> <a  href="<?php echo e(url('/faq')); ?>">FAQ</a></li>


                             </ul>
                         </li>
                         <li><a href="<?php echo e(url('/aboutUs')); ?>">ABOUT</a></li>
                         <li><a href="#">BUYER <i class="fa fa-angle-down"></i></a>
                             <ul>
                                 <li><a class="btn btn-default" href="<?php echo e(url('/freelancers')); ?>">Profile</a></li>
                                 <li><a class="btn btn-default" href="<?php echo e(url('/scoreboard')); ?>">Scoreboard</a></li>
                                 <li><a class="btn btn-default" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
                                 <li><a class="btn btn-default" href="<?php echo e(url('/dashboard')); ?>">Jobs View</a></li>
                                 <li><a class="btn btn-default" href="<?php echo e(url('/freelancers')); ?>">All Candidates</a></li>
                             </ul>
                         </li>
                         <li>
                             <a href="#">SELLER <i class="fa fa-angle-down"></i></a>
                             <ul>
                                 <li><a class="btn btn-default" href="<?php echo e(url('/managerequest')); ?>">Manage Requests</a></li>
                                 <li><a class="btn btn-default" href="<?php echo e(url('/searchjobs')); ?>">Jobs Search</a></li>
                                 <li><a class="btn btn-default" href="<?php echo e(url('/managepost')); ?>">Manage Posts</a></li>
                                 <li><a class="btn btn-default" href="<?php echo e(url('/dashboard/create')); ?>">Jobs Post</a></li>
                             </ul>
                         </li>
                         <li>
                             <a href="/portpolio">PORTPOLIO </a>

                         </li>
                         <li>
                             <a href="/blogs">BLOG <i class="fa fa-angle-down"></i></a>
                             <ul>
                                 <li><a href="/blogs/create">Post</a></li>
                             </ul>
                         </li>
                         <li><a href="/contact">CONTACT</a></li>
                     </ul>
                     <!-- End Menu-->
                 </nav>
                 </div>



             </div><!-- End Row-->

        </div><!-- End Container-->
        </header>
        <!-- End Header-->

<?php $__env->stopSection(); ?>

<!-- JavaScripts -->

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(function () {
            "use strict";

            $(window).scroll(function () {
                var $scrollTop = $(this).scrollTop();

                if ($scrollTop > 100) {
                    $(".navbar").addClass("navbar-active");
                } else {
                    $(".navbar").removeClass("navbar-active");
                }
            });


        });
    </script>
     <script>
        $(function()
        {
            $( "#skilltitle" ).autocomplete({
                source: "<?php echo e(URL::route('skillcomplete')); ?>",
                minLength: 1,
                select: function(event, ui) {

                }
            });
        });


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>