<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
     <?php if(isset($getlist) && !empty($getlist)): ?>
        <table class="table table-responsive table-hover">
            <thead>
                <th>Date</th>
                <th>desccription</th>
                <th>Amount</th>
            </thead>
                <?php foreach($getlist as $data): ?>
            <tr>
                <td><?php echo e($data->created_at); ?></td>
                <td><?php echo e($data->description); ?></td>
                <td><?php echo e($data->amount); ?></td>
            </tr>
                <?php endforeach; ?>
           
        </table>
         <?php else: ?>
            <div class="container" style="height:350px">
                <h4 align="center">Sorry no records found</h4>
            </div>
         <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>