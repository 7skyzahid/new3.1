<?php $__env->startSection('style'); ?>
    @parent
    <link rel="stylesheet" href="<?php echo asset('css/faq.css')?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <center><h1>Freelancer Requests</h1></center>
                <?php
                    $i= 0 ;
                    if(isset($buyerrequests) && !empty($buyerrequests)){
                 foreach ($buyerrequests  as $post=>$object) {
                //echo "<pre>";
                //var_dump($object);
                ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">Title: <a href="/dashboard/<?php echo $object[$i]->id; ?>"><?php echo $object[$i]->title; ?></a>; by <a href="/<?php $object[$i]->author; ?>"><?php $object[$i]->author; ?></a>
                            ; at amount $<?php $object[$i]->amount;?>
                            <?php if($object[$i]->payment_type == "full time"): ?>
                                (full time basis)
                            <?php elseif($object[$i]->payment_type == "hourly"): ?>
                                / hour basis
                            <?php endif; ?>

                        </div>
                        <div class="panel-body">
                            Keywords: 	&nbsp 	<?php echo e($object[$i]->tags); ?><br>
                            Start Date: &nbsp 	<?php echo e($object[$i]->startdate); ?><br>
                            Deadline: 	&nbsp 	<?php echo e($object[$i]->deadline); ?><br>
                            Description:&nbsp	<?php echo e($object[$i]->projectdescription); ?>

                            <a href="<?php echo $object[$i]->projectid;?>"> <span class="pull-right badge" >Offers <?php echo $object[$i]->requestsCount;?></span></a>
                        </div>

                    </div>
                
               <?php }
                }  else {
                    echo "No Requests";
                }?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>