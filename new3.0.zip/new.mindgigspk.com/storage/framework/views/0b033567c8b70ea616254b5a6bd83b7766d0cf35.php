<?php $__env->startSection('content'); ?>
    <link href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" rel="Stylesheet"></link>

    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js" ></script>
	<div class="clearfix"></div>

	<div class="clearfix"></div>


	<!-- Banner
    ================================================== -->
	<div id="banner">
		<div class="row">
		<div class="container">
			

				<div class="search-container">

					<!-- Form -->
					<h2>Find job</h2>

					<form action="returnjob" method="POST">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="col-md-3">
                            <input type="text" name="jobtitle" id="jobtitle" class="form-control" placeholder="job title" value=""/>
                        </div>

                        <div class="col-md-3">
                            <input type="text" name="country" id="jobcountry" class="form-control" placeholder="job Country" value=""/>
                        </div>
                        
                        <div class="col-md-3">
                            <input type="text" name="city" id="jobcity" class="form-control" placeholder="city" value=""/>
                        </div>

                        <div class="col-md-3">
                          <button class="btn btn-info">
                              <span class="glyphicon glyphicon-search "></span>
                              Search</button>
                        </div>
					</form><br><br>
					<!-- Browse Jobs -->
					<div class="browse-jobs leed">
						Browse job offers by <a href="browse-categories.html"> category</a> or <a href="#">location</a>
					</div>

					<!-- Announce -->
					<div class="announce">
						We’ve over <strong>15 000</strong> job offers for you!
					</div>

				</div>

			</div>
		</div>
		</div>
	</div>


<!-- Services -->
        <section class="paddings services position-relative">
            <div class="container">
                
                <i class="fa fa-cogs icon-section top right"></i> 



<!-- Title Heading --> 
                <div class="titles-heading">
                    <div class="line"></div>
                     <h1>Great Services
                        <span>
                          <i class="fa fa-star"></i>  
                          tristique senectus malesuada
                          <i class="fa fa-star"></i>  
                        </span>
                     </h1>
                </div> 
                <!-- End Title Heading --> 

              <!-- Row fuid-->
              <div class="row padding-top">
                 <!-- Item service-->
                  <div class="col-md-4">
                      <div class="item-service border-right">
                          <div class="row head-service">
                              <div class="col-md-2">
                                  <i class="fa fa-star"></i>                             
                              </div>
                              <div class="col-md-10">
                                  <h4>High Quality</h4>
                                  <h5>tristique senectus malesuada</h5>
                              </div>
                          </div>                          
                          <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam.</p>
                      </div>
                  </div>      
                  <!-- End Item service-->

                  <!-- Item service-->
                  <div class="col-md-4">
                      <div class="item-service border-right">
                          <div class="row head-service">
                              <div class="col-md-2">
                                 <i class="fa fa-fire"></i>                            
                              </div>
                              <div class="col-md-10">
                                  <h4>Ultra Hot Design</h4>
                                  <h5>tristique senectus malesuada</h5>
                              </div>
                          </div>                          
                          <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam.</p>
                      </div>
                  </div>      
                  <!-- End Item service-->

                  <!-- Item service-->
                  <div class="col-md-4">
                      <div class="item-service">
                          <div class="row head-service">
                              <div class="col-md-2">
                                  <i class="fa fa-cogs"></i>                    
                              </div>
                              <div class="col-md-10">
                                  <h4>Free Updates and Support</h4>
                                  <h5>tristique senectus malesuada</h5>
                              </div>
                          </div>                          
                          <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam.</p>
                      </div>
                  </div>      
                  <!-- End Item service-->
                 
              </div>
              <!-- End Row fuid-->

              <!-- Row fuid-->
              <div class="row">
                 <!-- Item service-->
                  <div class="col-md-4">
                      <div class="item-service border-right">
                          <div class="row head-service">
                              <div class="col-md-2">
                                  <i class="fa fa-thumbs-up"></i>                    
                              </div>
                              <div class="col-md-10">
                                  <h4>24/7 Support</h4>
                                  <h5>tristique senectus malesuada</h5>
                              </div>
                          </div>                          
                          <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam.</p>
                      </div>
                  </div>      
                  <!-- End Item service-->

                  <!-- Item service-->
                  <div class="col-md-4">
                      <div class="item-service border-right">
                          <div class="row head-service">
                              <div class="col-md-2">
                                  <i class="fa fa-plane"></i>                             
                              </div>
                              <div class="col-md-10">
                                  <h4>Flexible Solutions</h4>
                                  <h5>tristique senectus malesuada</h5>
                              </div>
                          </div>                          
                          <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam.</p>
                      </div>
                  </div>      
                  <!-- End Item service-->

                  <!-- Item service-->
                  <div class="col-md-4">
                      <div class="item-service">
                          <div class="row head-service">
                              <div class="col-md-2">
                                    <i class="fa fa-pencil"></i>                            
                              </div>
                              <div class="col-md-10">
                                  <h4>Original Design</h4>
                                  <h5>tristique senectus malesuada</h5>
                              </div>
                          </div>                          
                          <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam.</p>
                      </div>
                  </div>      
                  <!-- End Item service-->
                 
              </div>
              <!-- End Row fuid-->
               
            </div>
            <!-- End Container-->
        </section>
        <!-- End Services-->











	<!-- Content================================================== -->

	


<div class="container">
	<!-- Recent Jobs -->
		<div class="eleven columns">
			<div class="padding-right">
				<h3 class="margin-bottom-25">Recent Jobs</h3>
				<ul class="job-list">
                	<?php if(isset($jobs)): ?>
                    	<?php foreach($jobs as $job): ?>
							<li class="highlighted"><a href="job/<?php echo e($job->id); ?>">
								<img src="images/job-list-logo-01.png" alt="">
								<div class="job-list-content">
									<h4><?php echo e($job->title); ?>

                                		<?php if($job->payment_type =='full time'): ?>
                                   			<span class="full-time pull-right"><?php echo e($job->payment_type); ?></span>
                                		<?php endif; ?>

                                	<?php if($job->payment_type =='hourly'): ?>
                                        <span class="part-time pull-right"><?php echo e($job->payment_type); ?></span>
                                	<?php endif; ?>
                           			 </h4>
								<div class="job-icons">
									<span><i class="fa fa-briefcase"></i> <?php echo e($job->author); ?></span>
									<span><i class="fa fa-map-marker"></i><?php echo e($job->status); ?></span>
									<span><i class="fa fa-money"></i> <?php echo e($job->amount); ?>/ hour</span>
                                <p><?php echo e($job->description); ?></p>
								</div>
								</div>
						</a>

						<div class="clearfix"></div>
					</li>
                    <?php endforeach; ?>
                    <?php endif; ?>
				</ul>

				<a href="browse-jobs.html" class="button centered"><i class="fa fa-plus-circle"></i> Show More Jobs</a>
				<div class="margin-bottom-55"></div>
			</div>
		</div>

		<!-- Job Spotlight -->
		<div class="five columns">
			<h3 class="margin-bottom-5">Job Spotlight</h3>

			<!-- Navigation -->
			<div class="showbiz-navigation">
				<div id="showbiz_left_1" class="sb-navigation-left"><i class="fa fa-angle-left"></i></div>
				<div id="showbiz_right_1" class="sb-navigation-right"><i class="fa fa-angle-right"></i></div>
			</div>
			<div class="clearfix"></div>

			<!-- Showbiz Container -->
			<div id="job-spotlight" class="showbiz-container">
				<div class="showbiz" data-left="#showbiz_left_1" data-right="#showbiz_right_1" data-play="#showbiz_play_1" >
					<div class="overflowholder">

						<ul>

							<li>
								<div class="job-spotlight">
									<a href="#"><h4>Social Media: Advertising Coordinator <span class="part-time">Part-Time</span></h4></a>
									<span><i class="fa fa-briefcase"></i> Mates</span>
									<span><i class="fa fa-map-marker"></i> New York</span>
									<span><i class="fa fa-money"></i> $20 / hour</span>
									<p>As advertising & content coordinator, you will support our social media team in producing high quality social content for a range of media channels.</p>
									<a href="job-page.html" class="button">Apply For This Job</a>
								</div>
							</li>
</div>
</div>
</div>
</div>
</div></div></div>

<!-- Sponsors -->
        <section class="sponsors">
            <div class="overflow-sponsors">
                <div class="container paddings">

                   <h2>We have  earned the trust of <span> 25,869 </span>customers , including  these fine  companies</h2>
                   
                    <!-- Sponsors -->
                    <ul id="sponsors">

                        <!-- Sponsor -->
                        <li data-toggle="tooltip" title data-original-title="Tooltip Hover">
                            <a href="#"><img src="img/sponsors/logos/1.png" alt=""></a>
                        </li>  
                        <!-- Item Sponsor -->

                        <!-- Sponsor -->
                        <li data-toggle="tooltip" title data-original-title="Tooltip Hover">
                            <a href="#"><img src="img/sponsors/logos/6.png" alt=""></a>
                        </li>  
                        <!-- Item Sponsor -->

                        <!-- Sponsor -->
                        <li data-toggle="tooltip" title data-original-title="Tooltip Hover">
                            <a href="#"><img src="img/sponsors/logos/3.png" alt=""></a>
                        </li>  
                        <!-- Item Sponsor -->

                        <!-- Sponsor -->
                        <li data-toggle="tooltip" title data-original-title="Tooltip Hover">
                            <a href="#"><img src="img/sponsors/logos/4.png" alt=""></a>
                        </li>  
                        <!-- Item Sponsor -->

                        <!-- Sponsor -->
                        <li data-toggle="tooltip" title data-original-title="Tooltip Hover">
                            <a href="#"><img src="img/sponsors/logos/5.png" alt=""></a>
                        </li>  
                        <!-- Item Sponsor -->

                        <!-- Sponsor -->
                        <li data-toggle="tooltip" title data-original-title="Tooltip Hover">
                            <a href="#"><img src="img/sponsors/logos/6.png" alt=""></a>
                        </li>  
                        <!-- Item Sponsor -->

                        <!-- Sponsor -->
                        <li data-toggle="tooltip" title data-original-title="Tooltip Hover">
                            <a href="#"><img src="img/sponsors/logos/4.png" alt=""></a>
                        </li>  
                        <!-- Item Sponsor -->     

                    </ul>
                    <!-- End Sponsors --> 

                    <div class="circle">
                        <i class="fa fa-thumbs-up"></i>
                    </div>

                </div>
            </div>
        </section>
        <!-- End Sponsors -->



        <!-- post-testimonials -->
        <section class="paddings post-testimonials">
            <div class="container">
               <div class="row">  

                    <!-- Post --> 
                    <div class="col-md-6">
                        <h3>Latest Blog Posts</h3>
                         <!-- Box -->
                        <ul class="box">
                            <!-- Item Post --> 
                            <li class="row">
                                <!-- Date --> 
                                <div class="col-md-3">
                                    <div class="date"><span><i class="fa fa-calendar-o"></i>Sep</span>15</div>
                                </div>
                                <!-- End Date --> 
                                <div class="col-md-7">
                                    <div class="info">
                                        <h4>The Human Element</h4>
                                        <p>Lorem ipsum ea cum , pri no natum clita. </p>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="link">
                                       <a href="#" title="Read More"><i class="fa fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </li>
                            <!-- End Item Post --> 

                             <!-- Item Post --> 
                            <li class="row">
                                <!-- Date --> 
                                <div class="col-md-3">
                                    <div class="date"><span><i class="fa fa-calendar-o"></i>Sep</span>15</div>
                                </div>
                                <!-- End Date --> 
                                <div class="col-md-7">
                                    <div class="info">
                                        <h4>The Human Element</h4>
                                        <p>Lorem ipsum ea cum , pri no natum clita. </p>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="link">
                                       <a href="#" title="Read More"><i class="fa fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </li>
                            <!-- End Item Post --> 

                            <!-- Item Post --> 
                            <li class="row">
                                <!-- Date --> 
                                <div class="col-md-3">
                                    <div class="date"><span><i class="fa fa-calendar-o"></i>Sep</span>15</div>
                                </div>
                                <!-- End Date --> 
                                <div class="col-md-7">
                                    <div class="info">
                                        <h4>The Human Element</h4>
                                        <p>Lorem ipsum ea cum , pri no natum clita. </p>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="link">
                                       <a href="#" title="Read More"><i class="fa fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </li>
                            <!-- End Item Post --> 

                            <!-- Item Post --> 
                            <li class="row">
                                <!-- Date --> 
                                <div class="col-md-3">
                                    <div class="date"><span><i class="fa fa-calendar-o"></i>Sep</span>15</div>
                                </div>
                                <!-- End Date --> 
                                <div class="col-md-7">
                                    <div class="info">
                                        <h4>The Human Element</h4>
                                        <p>Lorem ipsum ea cum , pri no natum clita. </p>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="link">
                                       <a href="#" title="Read More"><i class="fa fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </li>
                            <!-- End Item Post --> 

                            <!-- Item Post --> 
                            <li class="row">
                                <!-- Date --> 
                                <div class="col-md-3">
                                    <div class="date"><span><i class="fa fa-calendar-o"></i>Sep</span>15</div>
                                </div>
                                <!-- End Date --> 
                                <div class="col-md-7">
                                    <div class="info">
                                        <h4>The Human Element</h4>
                                        <p>Lorem ipsum ea cum , pri no natum clita. </p>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="link">
                                       <a href="#" title="Read More"><i class="fa fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </li>
                            <!-- End Item Post --> 

                        </ul>
                        <!-- End Box -->
                    </div>
                    <!-- End Post --> 

                    <!-- Testimonial --> 
                    <div class="col-md-6">
                        <h3>Recent Testimonials</h3>
                        <!-- Box -->
                        <ul class="box">
                            
                            <!-- Item testimonial --> 
                            <li class="row">
                                <!-- Date --> 
                                <div class="col-md-3">
                                    <div class="photo">
                                        <img src="img/testimonials/1.jpg" alt="">
                                    </div>
                                </div>
                                <!-- End Date --> 
                                <div class="col-md-9">
                                    <div class="name">
                                        <h4>Federic Gordon
                                            <span>Front End</span>
                                        </h4>                                        
                                    </div>
                                    <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. </p>
                                </div>
                            </li>
                            <!-- End Item testimonial --> 

                            <!-- Item testimonial --> 
                            <li class="row">
                                <!-- Date --> 
                                <div class="col-md-3">
                                    <div class="photo">
                                        <img src="img/testimonials/2.jpg" alt="">
                                    </div>
                                </div>
                                <!-- End Date --> 
                                <div class="col-md-9">
                                    <div class="name">
                                        <h4>Federic Gordon
                                            <span>Front End</span>
                                        </h4>                                        
                                    </div>
                                    <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. </p>
                                </div>
                            </li>
                            <!-- End Item testimonial --> 

                            <!-- Item testimonial --> 
                            <li class="row">
                                <!-- Date --> 
                                <div class="col-md-3">
                                    <div class="photo">
                                        <img src="img/testimonials/3.jpg" alt="">
                                    </div>
                                </div>
                                <!-- End Date --> 
                                <div class="col-md-9">
                                    <div class="name">
                                        <h4>Federic Gordon
                                            <span>Front End</span>
                                        </h4>                                        
                                    </div>
                                    <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. </p>
                                </div>
                            </li>
                            <!-- End Item testimonial --> 

                            <!-- Item testimonial --> 
                            <li class="row">
                                <!-- Date --> 
                                <div class="col-md-3">
                                    <div class="photo">
                                        <img src="img/testimonials/1.jpg" alt="">
                                    </div>
                                </div>
                                <!-- End Date --> 
                                <div class="col-md-9">
                                    <div class="name">
                                        <h4>Federic Gordon
                                            <span>Front End</span>
                                        </h4>                                        
                                    </div>
                                    <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. </p>
                                </div>
                            </li>
                            <!-- End Item testimonial --> 

                        </ul>
                        <!-- End Box -->
                    </div>
                    <!-- End Testimonial --> 

               </div>                
            </div>
        </section>
        <!-- End post-testimonials -->






<script>
    $(function()
    {
        $( "#jobtitle" ).autocomplete({
            source: "<?php echo e(URL::route('autocomplete')); ?>",
            minLength: 1,
            select: function(event, ui) {

            }
        });
    });
	$(function()
	{
		$( "#jobcountry" ).autocomplete({
			source: "<?php echo e(URL::route('autocompletecountry')); ?>",
			minLength: 1,
			select: function(event, ui) {

			}
		});
	});
    $(function()
    {
        $( "#jobcity" ).autocomplete({
            source: "<?php echo e(URL::route('autocompletejobcity')); ?>",
            minLength: 1,
            select: function(event, ui) {

            }
        });
    });

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>