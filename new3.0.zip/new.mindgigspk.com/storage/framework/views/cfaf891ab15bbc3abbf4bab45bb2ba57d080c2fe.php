

<?php $__env->startSection('style'); ?>
    @parent
    <link rel="stylesheet" href="<?php echo asset('css/faq.css')?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <center><h1>Bidded Posts</h1></center>

                <?php foreach($biddedposts as $post): ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">Title: <a href="/dashboard/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a>; by <a href="/<?php echo e($post->author); ?>"><?php echo e($post->author); ?></a>
                            ; at amount $<?php echo e($post->amount); ?>

                            <?php if($post->payment_type == "full time"): ?>
                                (full time basis)
                            <?php elseif($post->payment_type == "hourly"): ?>
                                / hour basis
                            <?php endif; ?>

                        </div>
                        <div class="panel-body">
                            Keywords: 	&nbsp 	<?php echo e($post->tags); ?><br>
                            Start Date: &nbsp 	<?php echo e($post->startdate); ?><br>
                            Deadline: 	&nbsp 	<?php echo e($post->deadline); ?><br>
                            Description:&nbsp	<?php echo e($post->description); ?>

                        </div>

                        <?php if((Auth::check()== true) && (Auth::user()->name == $post->author)): ?>
                            <div>
                                <form method="POST" action="dashboard/<?php echo e($post->id); ?>" id="fb">
                                    <?php echo e(method_field('DELETE')); ?>

                                    <?php echo e(csrf_field()); ?>

                                    <button type="button" class="btn btn-primary" onclick="window.location.href='dashboard/<?php echo e($post->id); ?>/editpost'">Edit</button>
                                    <button type="submit" class="btn btn-primary" >Delete</button>
                                </form>
                            </div>
                        <?php elseif((Auth::check()== true) && (Auth::user()->name != $post->author) && ($post->status != "awarded")): ?>
                            <div id="notifier<?php echo e($post->id); ?>" style="background-color:green;color:white;display:none;">Your bid has successfully been placed!</div>

                            <div id="testdiv"></div>

                        <?php endif; ?>

                    </div>
                <?php endforeach; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>