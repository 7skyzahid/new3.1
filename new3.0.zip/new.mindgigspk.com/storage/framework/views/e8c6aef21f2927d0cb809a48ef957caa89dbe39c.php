<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
	<br><br>
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-default">
				<div class="panel-heading">Post</div>

				<div class="panel-body">

					<form method="POST" action="/dashboard" id="fp">
						<?php echo csrf_field(); ?>



						<div class="form-group row">
							<div class="col-xs-10">
								<textarea class="col-xs-offset-1 form-control" name="post" rows="5" type="text" id="post"></textarea>
							</div>
						</div>

						<div class="form-group row">
								<button type="submit" onclick="send(event)" class="col-xs-offset-1 btn btn-primary">Post</button>
						</div>


					</form>

					<div id="successMessage">old message</div>

				</div>
			</div>

			<div id="jobpanel">

			<?php if(count($psts) >=  1): ?>		
			<h2>Job Posts:-</h2>
			<div class="panel panel-default" id="postspanel">
				<?php foreach($psts as $post): ?>
				<div class="panel-heading" id="divph<?php echo e($post->id); ?>"><?php echo e($post->id); ?></div>
				<div class="panel-body" id="divpb<?php echo e($post->id); ?>"><?php echo e($post->post); ?></div>
				<?php endforeach; ?>
			</div>
			<?php endif; ?>		
			
			</div>
	
		</div>
	</div>
</div>

<?php $__env->startSection('scripts'); ?>

			<script type="text/javascript">
/*
$(document).ready(function(){

	$.get('dashboard',function(data){
    	alert(data.psts);
    });
            
});
*/
function send(event){
	event.preventDefault();
//	alert($("#post").val());

	$.ajax({
		type: "POST",
		url: "/dashboard",
		data: {pst: $("#post").val(), _token: "<?php echo e(Session::token()); ?>"}
	});
	$("#post").val("");
}


     
			</script>

<?php $__env->stopSection(); ?>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>