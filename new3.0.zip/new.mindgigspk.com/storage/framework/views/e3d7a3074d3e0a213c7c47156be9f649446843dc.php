<?php $__env->startSection('content'); ?>
<?php if(!empty($uprof)): ?>
    <div id="titlebar" class="resume" style="background-color: white">
        <div class="container" >
            <div class="ten columns">
                <div class="resume-titlebar">
                    <?php if(isset($uprof->profilepic)): ?>
                    <img src="images/<?php echo e($uprof->profilepic); ?>" alt="">
                    <?php endif; ?>
                    <div class="resumes-list-content">
                        <h4>
                            <?php if(isset($uprof)): ?>
                            <?php echo e(($uprof->username)); ?><span>Developer</span></h4>
                        <span class="icons"><i class="fa fa-map-marker"></i>
                        <?php if(isset($uprof->country)): ?>
                            <?php echo e($uprof->country); ?>

                            <?php endif; ?>
                        </span>
                        <span class="icons"><i class="fa fa-money"></i>
                            <?php if(isset($uprof->hourlyrate)): ?>
                                <?php echo e($uprof->hourlyrate); ?>

                            <?php endif; ?> / hour</span>
                        <span class="icons"><a href="#"><i class="fa fa-link"></i> Website</a></span>
                        <span class="icons"><a href="mailto:john.doe@example.com"><i class="fa fa-envelope"></i> john.doe@example.com</a></span>
                        <?php if(isset($skills)): ?>
                        <div class="skills">

                            <span><?php echo e($skills->title); ?></span>

                        </div>
                        <?php endif; ?>
                        
                         <?php if(!empty($uprof->languages)): ?>
                        <div class="skills">
                         
                            <span><?php echo e($uprof->languages); ?></span>

                        </div>
                        <?php endif; ?>
                        
                        <div class="clearfix"></div>
                        <?php endif; ?>
                        
                    </div>
                </div>
            </div>

            <div class="six columns">
                <div class="two-buttons">

                    <a href="#small-dialog" class="popup-with-zoom-anim button"><i class="fa fa-envelope"></i> Send Message</a>

                    <div id="small-dialog" class="zoom-anim-dialog mfp-hide apply-popup">
                        <div class="small-dialog-headline">
                            <?php if(isset($uprof->username)): ?>
                            <h2>Send Message to

                                <?php echo e($uprof->username); ?>


                            </h2>
                            <?php endif; ?>
                        </div>

                        <div class="small-dialog-content">
                            <form action="sendmail" method="post" >

                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                <input type="hidden" name="username"  value="<?php echo e($uprof->username); ?>"/>
                                <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                               <strong><?php echo e($errors->first('username')); ?></strong>
                             </span>
                                <?php endif; ?>
                                <input type="text" name="fullname" placeholder="Full Name" value=""/>
                                <?php if($errors->has('fullname')): ?>
                                    <span class="help-block">
                               <strong><?php echo e($errors->first('fullname')); ?></strong>
                             </span>
                                <?php endif; ?>
                                <input type="email" name="emailaddress" placeholder="Your Email Address" value=""/>
                                <?php if($errors->has('emailaddress')): ?>
                                    <span class="help-block">
                               <strong><?php echo e($errors->first('emailaddress')); ?></strong>
                             </span>
                                <?php endif; ?>
                                <input type="text" name="subject" placeholder="Subject" value=""/>
                                <?php if($errors->has('subject')): ?>
                                    <span class="help-block">
                               <strong><?php echo e($errors->first('subject')); ?></strong>
                             </span>
                                <?php endif; ?>
                                <textarea placeholder="Message" name="message"></textarea>
                                <button class="send">Send To <?php echo e($uprof->username); ?></button>
                            </form>
                        </div>

                    </div>
                    <a href="#" class="button dark"><i class="fa fa-star"></i> Bookmark This Resume</a>
                </div>
            </div>

        </div>
    </div>


    <!-- Content
    ================================================== -->
    <div class="container" style="background-color: white">
        <!-- Recent Jobs -->
         <?php if(\Illuminate\Support\Facades\Session::has('message')): ?>
            <p class="alert alert-success"><?php echo e(\Illuminate\Support\Facades\Session::get('message')); ?></p>
    <?php endif; ?>
        <div class="eight columns">
            <div class="padding-right">

                <h3 class="margin-bottom-15">About Me</h3>

                <p class="margin-reset">
                <?php if(isset($uprof->about)): ?>
                    <?php echo e($uprof->about); ?>

                    <?php endif; ?>
                </p>

                <br>
                <h3 class="margin-bottom-15">Experience</h3>
                <div class="margin-reset">
                    <?php if(isset($experienceData)): ?>
                       <?php foreach($experienceData as $experience): ?>
                            <small class="date"> <?php echo e(($experience->created_at)); ?></small><br>
                            <strong><?php echo e(($experience->position)); ?></strong><br>
                <div class="skills">

                    <span><?php echo e($experience->company); ?></span><br><br>

                </div>
                            <p><?php echo e(($experience->description)); ?></p>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <br>
                <ul>
                    <li>
                        <?php if(isset($portfilioData)): ?>
                            <?php foreach($portfilioData as $port): ?>
                        <a href="job-page.html"></a>
                            <img src="images/<?php echo e($port->image); ?>" height="150" width="150" alt="">
                            <div class="job-list-content">
                                <h4><span class="part-time">Part-Time</span></h4>
                                <div class="job-icons">
                                    <span><i class="fa fa-briefcase"></i> <?php echo e($port->title); ?></span>
                                    <span><i class="fa fa-map-marker"></i> London</span>
                                    <span><i class="fa fa-money"></i> $50 / hour</span>
                                </div>
                                <p><?php echo e($port->description); ?></p>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </li>
                </ul>

            </div>
        </div>


        <!-- Widgets -->
        <div class="eight columns">

            <h3 class="margin-bottom-20">Education</h3>

            <!-- Resume Table -->
            <dl class="resume-table">
                <?php if(isset($educationData)): ?>
                <?php foreach($educationData as $experience): ?>
                <dt>

                    <small class="date"> <?php echo e(($experience->created_at)); ?></small>
                    <strong><?php echo e(($experience->institute)); ?></strong>
                        <div class="skills">

                            <span><?php echo e($experience->degree); ?></span><br><br>

                        </div>

                </dt>
                <dd>
                    <p><?php echo e(($experience->description)); ?></p>
                </dd>
                    <?php endforeach; ?>
                        <?php endif; ?>
            </dl>


        </div>
        
        
        
        
        <!-- Certificate-->
        <div class="eight columns">

            <h3 class="margin-bottom-20">certificates</h3>

            <!-- Resume Table -->
            <dl class="resume-table">
                <?php if(isset($certificateData)): ?>
                <?php foreach($certificateData as $certificate): ?>
                <dt>

                    <small class="date"> <?php echo e(($certificate->created_at)); ?></small>
                    <strong><?php echo e(($certificate->title)); ?></strong>
                        <div class="skills">

                            <span><?php echo e($certificate->provider); ?></span><br><br>

                        </div>

                </dt>
                <dd>
                    <p><?php echo e(($certificate->description)); ?></p>
                </dd>
                    <?php endforeach; ?>
                        <?php endif; ?>
            </dl>


        </div>

    </div>
    <?php else: ?>
    <h1>Sorry No Profile Found</h1>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>